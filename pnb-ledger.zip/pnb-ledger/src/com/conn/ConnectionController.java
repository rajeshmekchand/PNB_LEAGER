package com.conn;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionController {

	public static Properties loadPropertiesFile() throws Exception {

		InputStream in = ConnectionController.class.getClassLoader().getResourceAsStream("/db.properties");
		Properties prop = new Properties();
		prop.load(in);
		in.close();
		return prop;
	}

	public static Connection createConnection() {
		Connection con = null;
		try {
			Properties prop = loadPropertiesFile();
			String driverClass = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String username = prop.getProperty("username");
			String password = prop.getProperty("password");

			Class.forName(driverClass);

			con = DriverManager.getConnection(url, username, password);

			if (con != null) {
//				System.out.println("connection created successfully.");
				return con;
			}else {
				System.out.println(" unable to create connection");
			}

		}catch (SQLException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		/*finally {

			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}*/
		return con;
	}




	public static void dbclose(Connection con) throws SQLException {
		try {
			if (con != null) {
				con.close();
				System.out.println("DataBase now close");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
