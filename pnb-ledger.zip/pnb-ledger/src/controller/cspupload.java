package controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;

import com.conn.ConnectionController;

/**
 * Servlet implementation class cspupload
 */
@WebServlet("/cspupload")
@MultipartConfig(maxFileSize = 16177215)
public class cspupload extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public cspupload() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
//		System.out.println("1");
		Part filepart = request.getPart("inputfile1");
		DataFormatter df = new DataFormatter();
		String role = "user";

		InputStream inputStream = null;
		int n = 0;
		if (filepart != null) {


			inputStream = filepart.getInputStream();
			//System.out.println(inputStream);

			Connection con = ConnectionController.createConnection();
			PreparedStatement ps = null;
			String message = null;
			try {

				// Class.forName("com.mysql.jdbc.Driver");
				// conn =
				// (Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/nbgb_banking_ledger","root","root");

//				System.out.println("done");


				FileInputStream input = (FileInputStream) inputStream;
//				System.out.println(input);
				POIFSFileSystem fs = new POIFSFileSystem(input);

//				System.out.println(fs);
				HSSFWorkbook wb = new HSSFWorkbook(fs);
//				System.out.println(wb);
				HSSFSheet sheet = wb.getSheetAt(0);
//				System.out.println(sheet);
				Row row;
//				System.out.println("total rows are...." + sheet.getLastRowNum());

				for (int i = 1; i <= sheet.getLastRowNum(); i++) {
					// int i=1;
					row = sheet.getRow(i);
//					System.out.println("row no." + row);
//					System.out.println(row.getCell(1));

//					System.out.println("done2");

					String user_id = df.formatCellValue(row.getCell(1));

//					System.out.println(user_id);

					String user_name =df.formatCellValue(row.getCell(2));

//					System.out.println(user_name);

					String password = df.formatCellValue(row.getCell(3));
//					System.out.println(password);

					String qry = "Insert into user_pnb(user_id, user_name, password, role)values" + "(?,?,?,?)";

					ps = con.prepareStatement(qry);
					ps.setString(1, user_id);
					ps.setString(2, user_name);
					ps.setString(3, password);

					ps.setString(4, role);

//					System.out.println(ps);
//					System.out.println(filepart);
					n = ps.executeUpdate();

				}
				if (n>0) {
					request.getSession().setAttribute("msgs", "Data Uploaded Successfully");
					response.sendRedirect("csp_uploader.jsp");
				}else {
					request.getSession().setAttribute("msgs", "Data Not Uploaded-Check Data Format");
					response.sendRedirect("csp_uploader.jsp");
				}


			} catch (Exception e) {
				// TODO: handle exception

				message = "Error : " + e.getMessage();

				e.printStackTrace();
				out.print("Choose Excel File");
				request.getSession().setAttribute("msgs", "Error Database");
				response.sendRedirect("csp_uploader.jsp");

			} finally {
				try {
					ps.close();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				System.gc();
				/* System.out.println("complete"); */

			}
		}

	}

	public String getValue(Cell cell1) {

		String value = "";
		if (cell1 == null) {
			return value;
		}
		/* System.out.println("cell1..." +cell1); */
		switch (cell1.getCellType()) {

		case Cell.CELL_TYPE_STRING:
			value = cell1.getRichStringCellValue().getString();
			// System.out.println("CELL_TYPE_STRING"+value);
			break;

		case Cell.CELL_TYPE_NUMERIC:
			if (DateUtil.isCellDateFormatted(cell1)) {

				value = String.valueOf(cell1.getNumericCellValue());
				// System.out.println("CELL_TYPE_NUMERIC"+value);
			} else {
				value = String.valueOf(cell1.getNumericCellValue());
				// System.out.println("CELL_TYPE_NUMERIC"+value);
			}
			break;

		case Cell.CELL_TYPE_BOOLEAN:
			value = String.valueOf(cell1.getBooleanCellValue());
			// System.out.println("CELL_TYPE_BOOLEAN"+value);
			break;

		case Cell.CELL_TYPE_FORMULA:

			value = String.valueOf(cell1.getNumericCellValue());
			// System.out.println("CELL_TYPE_FORMULA"+value);
			// System.out.println(cell1.getCellFormula());
			break;

		case Cell.CELL_TYPE_ERROR:

			value = String.valueOf(cell1.getErrorCellValue());

		default:
			value = cell1.getRichStringCellValue().getString();
//			System.out.println("Defalut " + value);
		}
		return value;

	}

}
