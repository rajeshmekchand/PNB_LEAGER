package controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;

import com.conn.ConnectionController;

/**
 * Servlet implementation class upservelet
 */
@WebServlet("/upservelet")
@MultipartConfig(maxFileSize = 16177215)
public class upservelet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public upservelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/* request.getSession().removeAttribute("msg"); */
		PrintWriter out = response.getWriter();
//		System.out.println("1");
		Part filepart = request.getPart("inputfile");

		String date = request.getParameter("datepicker");
		InputStream inputStream = null;
		int n = 0;
//		System.out.println("month: " + request.getParameter("month") + " year: " + request.getParameter("year"));

		if (filepart != null) {

			inputStream = filepart.getInputStream();
			/* System.out.println(inputStream); */
			String month = request.getParameter("month");
			String year = request.getParameter("year");
			/* System.out.println("month: " + month + " year: " + year); */
			DataFormatter df = new DataFormatter();

			Connection con = ConnectionController.createConnection();
			String message = null;
			PreparedStatement ps = null;
			try {

				// Class.forName("com.mysql.jdbc.Driver");
				// conn =
				// (Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/nbgb_banking_ledger","root","root");

				/* System.out.println("done"); */


				FileInputStream input = (FileInputStream) inputStream;
				/* System.out.println(input); */
				POIFSFileSystem fs = new POIFSFileSystem(input);

				/* System.out.println(fs); */
				HSSFWorkbook wb = new HSSFWorkbook(fs);
				/* System.out.println(wb); */
				HSSFSheet sheet = wb.getSheetAt(0);
				/* System.out.println(sheet); */
				Row row;
				/* System.out.println("total rows are...." + sheet.getLastRowNum()); */

				for (int i = 1; i <= sheet.getLastRowNum(); i++) {
					// int i=1;
					row = sheet.getRow(i);



					String NAME = df.formatCellValue(row.getCell(0));
					String AGENT_ID = df.formatCellValue(row.getCell(1));
					String CSP_LOC = df.formatCellValue(row.getCell(2));
					String BR_NAME = df.formatCellValue(row.getCell(3));
					String ACC_NO = df.formatCellValue(row.getCell(4));
					String PAN = df.formatCellValue(row.getCell(5));
					String MOBILE = df.formatCellValue(row.getCell(6));
					String ZONE_OFFICE_DESCRIPTION = df.formatCellValue(row.getCell(7));
					String CIRCLE_OFFICE = df.formatCellValue(row.getCell(8));
					String AGENT_TYPE = df.formatCellValue(row.getCell(9));
					String STATE_NAME = df.formatCellValue(row.getCell(10));
					String NO_OF_WORKING_DAYS = df.formatCellValue(row.getCell(11));
					String PMJJBY_CNT = getValue (row.getCell(12));
					String PMJJBY_AMT = getValue (row.getCell(13));
					String PMJJBY_COMM = getValue (row.getCell(14));
					String PMSBY_CNT = getValue (row.getCell(15));
					String PMSBY_AMT = getValue (row.getCell(16));
					String PMSBY_COMM = getValue (row.getCell(17));
					String APY_CNT = getValue (row.getCell(18));
					String APY_AMT = getValue (row.getCell(19));
					String APY_COMM = getValue (row.getCell(20));
					String RD_CNT = getValue (row.getCell(21));
					String RD_AMT = getValue (row.getCell(22));
					String RD_COMM = getValue (row.getCell(23));
					String FD_CNT = getValue (row.getCell(24));
					String FD_AMT = getValue (row.getCell(25));
					String FD_COMM = getValue (row.getCell(26));
					String EKYC_ENROLLMENT_CNT = getValue (row.getCell(27));
					String EKYC_ENROLLMENT_AMT = getValue (row.getCell(28));
					String EKYC_ENROLLMENT_COMM = getValue (row.getCell(29));
					String INDO_NEPAL_TRANSACTION_CNT = getValue (row.getCell(30));
					String INDO_NEPAL_TRANSACTION_AMT = getValue (row.getCell(31));
					String INDO_NEPAL_TRANSACTION = getValue (row.getCell(32));
					String IMPS_TRANSACTION_CNT = getValue (row.getCell(33));
					String IMPS_TRANSACTION_AMT = getValue (row.getCell(34));
					String IMPS_TRANSACTION_COMM = getValue (row.getCell(35));
					String AEPS_ONUS_DEPOSIT_CNT = getValue (row.getCell(36));
					String AEPS_ONUS_DEPOSIT_AMT = getValue (row.getCell(37));
					String AEPS_ONUS_DEPOSIT_COMM = getValue (row.getCell(38));
					String AEPS_OFFUS_DEPOSIT_CNT = getValue (row.getCell(39));
					String AEPS_OFFUS_DEPOSIT_AMT = getValue (row.getCell(40));
					String AEPS_OFFUS_DEPOSIT_COMM = getValue (row.getCell(41));
					String AEPS_ONUS_WITHDRAWAL_CNT = getValue (row.getCell(42));
					String AEPS_ONUS_WITHDRAWAL_AMT = getValue (row.getCell(43));
					String AEPS_ONUS_WITHDRAWAL_COMM = getValue (row.getCell(44));
					String AEPS_OFFUS_WITHDRAWAL_CNT = getValue (row.getCell(45));
					String AEPS_OFFUS_WITHDRAWAL_AMT = getValue (row.getCell(46));
					String AEPS_OFFUS_WITHDRAWAL_COMM = getValue (row.getCell(47));
					String AEPS_FUND_TRANSFER_ONUS_CNT = getValue (row.getCell(48));
					String AEPS_FUND_TRANSFER_ONUS_AMT = getValue (row.getCell(49));
					String AEPS_FUND_TRANSFER_ONUS_COMM = getValue (row.getCell(50));
					String AEPS_FUND_TRANSFER_OFFUS_CNT = getValue (row.getCell(51));
					String AEPS_FUND_TRANSFER_OFFUS_AMT = getValue (row.getCell(52));
					String AEPS_FUND_TRANSFER_OFFUS_COMM = getValue (row.getCell(53));
					String THIRD_PARTY_DEPOSIT_CNT = getValue (row.getCell(54));
					String THIRD_PARTY_DEPOSIT_AMT = getValue (row.getCell(55));
					String THIRD_PARTY_DEPOSIT_COMM = getValue (row.getCell(56));
					String BBPS_CNT = getValue (row.getCell(57));
					String BBPS_AMT = getValue (row.getCell(58));
					String BBPS_COMM = getValue (row.getCell(59));
					String RUPAY_ONUS_WITHDRWAL_CNT = getValue (row.getCell(60));
					String RUPAY_ONUS_WITHDRWAL_AMT = getValue (row.getCell(61));
					String RUPAY_ONUS_WITHDRWAL_COMM = getValue (row.getCell(62));
					String RUPAY_OFFUS_WITHDRWAL_CNT = getValue (row.getCell(63));
					String RUPAY_OFFUS_WITHDRWAL_AMT = getValue (row.getCell(64));
					String RUPAY_OFFUS_WITHDRWAL_COMM = getValue (row.getCell(65));
					String SHG_ONUS_WITHDRWAL_CNT = getValue (row.getCell(66));
					String SHG_ONUS_WITHDRWAL_AMT = getValue (row.getCell(67));
					String SHG_ONUS_WITHDRWAL_COMM = getValue (row.getCell(68));
					String SHG_OFFUS_WITHDRWAL_CNT = getValue (row.getCell(69));
					String SHG_OFFUS_WITHDRWAL_AMT = getValue (row.getCell(70));
					String SHG_OFFUS_WITHDRWAL_COMM = getValue (row.getCell(71));
					String SHG_FUND_TRANSFER_ONUS_CNT = getValue (row.getCell(72));
					String SHG_FUND_TRANSFER_ONUS_AMT = getValue (row.getCell(73));
					String SHG_FUND_TRANSFER_ONUS_COMM = getValue (row.getCell(74));
					String SHG_FUND_TRANSFER_OFFUS_CNT = getValue (row.getCell(75));
					String SHG_FUND_TRANSFER_OFFUS_AMT = getValue (row.getCell(76));
					String SHG_FUND_TRANSFER_OFFUS_COMM = getValue (row.getCell(77));
					String AADHAR_SEEDING_CNT = getValue (row.getCell(78));
					String AADHAR_SEEDING_AMT = getValue (row.getCell(79));
					String AADHAR_SEEDING_COMM = getValue (row.getCell(80));
					String RENEW_TD_AND_RD_CNT = getValue (row.getCell(81));
					String RENEW_TD_AND_RD_AMT = getValue (row.getCell(82));
					String RENEW_TD_AND_RD_COMM = getValue (row.getCell(83));
					String NEFT_CNT = getValue (row.getCell(84));
					String NEFT_AMT = getValue (row.getCell(85));
					String NEFT_COMM = getValue (row.getCell(86));
					String PASSBOOK_PRINTING_CNT = getValue (row.getCell(87));
					String PASSBOOK_PRINTING_AMT = getValue (row.getCell(88));
					String PASSBOOK_PRINTING_COMM = getValue (row.getCell(89));
					String STOP_CHEQUE_CNT = getValue (row.getCell(90));
					String STOP_CHEQUE_AMT = getValue (row.getCell(91));
					String STOP_CHEQUE_COMM = getValue (row.getCell(92));
					String SMS_ALERT_CNT = getValue (row.getCell(93));
					String SMS_ALERT_AMT = getValue (row.getCell(94));
					String SMS_ALERT_COMM = getValue (row.getCell(95));
					String APPLY_NEW_DEBIT_CARD_CNT = getValue (row.getCell(96));
					String APPLY_NEW_DEBIT_CARD_AMT = getValue (row.getCell(97));
					String APPLY_NEW_DEBIT_CARD_COMM = getValue (row.getCell(98));
					String BLOCK_DEBIT_CARD_CNT = getValue (row.getCell(99));
					String BLOCK_DEBIT_CARD_AMT = getValue (row.getCell(100));
					String BLOCK_DEBIT_CARD_COMM = getValue (row.getCell(101));
					String NEW_CHEQUE_BOOK_REQUEST_CNT = getValue (row.getCell(102));
					String NEW_CHEQUE_BOOK_REQUEST_AMT = getValue (row.getCell(103));
					String NEW_CHEQUE_BOOK_REQUEST_COMM = getValue (row.getCell(104));
					String MOBILE_SEEDING_CNT = getValue (row.getCell(105));
					String MOBILE_SEEDING_AMT = getValue (row.getCell(106));
					String MOBILE_SEEDING_COMM = getValue (row.getCell(107));
					String CHEQUE_COLLECTION_CNT = getValue (row.getCell(108));
					String CHEQUE_COLLECTION_AMT = getValue (row.getCell(109));
					String CHEQUE_COLLECTION_COMM = getValue (row.getCell(110));
					String ACCOPEN_AVGBAL_COMM_AMOUNT = getValue(row.getCell(111));
					String PNB_ONE_COUNT = getValue(row.getCell(112));
					String PNB_ONE_AMOUNT = getValue(row.getCell(113));
					String PNB_ONE_COMMISSION = getValue(row.getCell(114));

					String TOTAL = getValue (row.getCell(115));
					String CSP_SHARE = getValue (row.getCell(116));
					String CSP_TDS = getValue (row.getCell(117));
					String NET_PAYABLE = getValue (row.getCell(118));




					String qry = "Insert into pnb_dbs(NAME,AGENT_ID,CSP_LOC,BR_NAME,ACC_NO,PAN,MOBILE,ZONE_OFFICE_DESCRIPTION,CIRCLE_OFFICE,AGENT_TYPE," +
							"STATE_NAME,NO_OF_WORKING_DAYS,PMJJBY_CNT,PMJJBY_AMT,PMJJBY_COMM,PMSBY_CNT,PMSBY_AMT,PMSBY_COMM," +
							"APY_CNT,APY_AMT,APY_COMM,RD_CNT,RD_AMT,RD_COMM,FD_CNT,FD_AMT,FD_COMM,EKYC_ENROLLMENT_CNT," +
							"EKYC_ENROLLMENT_AMT,EKYC_ENROLLMENT_COMM,INDO_NEPAL_TRANSACTION_CNT,INDO_NEPAL_TRANSACTION_AMT," +
							"INDO_NEPAL_TRANSACTION,IMPS_TRANSACTION_CNT,IMPS_TRANSACTION_AMT,IMPS_TRANSACTION_COMM," +
							"AEPS_ONUS_DEPOSIT_CNT,AEPS_ONUS_DEPOSIT_AMT,AEPS_ONUS_DEPOSIT_COMM,AEPS_OFFUS_DEPOSIT_CNT," +
							"AEPS_OFFUS_DEPOSIT_AMT,AEPS_OFFUS_DEPOSIT_COMM,AEPS_ONUS_WITHDRAWAL_CNT,AEPS_ONUS_WITHDRAWAL_AMT," +
							"AEPS_ONUS_WITHDRAWAL_COMM,AEPS_OFFUS_WITHDRAWAL_CNT,AEPS_OFFUS_WITHDRAWAL_AMT,AEPS_OFFUS_WITHDRAWAL_COMM," +
							"AEPS_FUND_TRANSFER_ONUS_CNT,AEPS_FUND_TRANSFER_ONUS_AMT,AEPS_FUND_TRANSFER_ONUS_COMM," +
							"AEPS_FUND_TRANSFER_OFFUS_CNT,AEPS_FUND_TRANSFER_OFFUS_AMT,AEPS_FUND_TRANSFER_OFFUS_COMM," +
							"THIRD_PARTY_DEPOSIT_CNT,THIRD_PARTY_DEPOSIT_AMT,THIRD_PARTY_DEPOSIT_COMM,BBPS_CNT," +
							"BBPS_AMT,BBPS_COMM,RUPAY_ONUS_WITHDRWAL_CNT,RUPAY_ONUS_WITHDRWAL_AMT,RUPAY_ONUS_WITHDRWAL_COMM," +
							"RUPAY_OFFUS_WITHDRWAL_CNT,RUPAY_OFFUS_WITHDRWAL_AMT,RUPAY_OFFUS_WITHDRWAL_COMM,SHG_ONUS_WITHDRWAL_CNT," +
							"SHG_ONUS_WITHDRWAL_AMT,SHG_ONUS_WITHDRWAL_COMM,SHG_OFFUS_WITHDRWAL_CNT,SHG_OFFUS_WITHDRWAL_AMT," +
							"SHG_OFFUS_WITHDRWAL_COMM,SHG_FUND_TRANSFER_ONUS_CNT,SHG_FUND_TRANSFER_ONUS_AMT,SHG_FUND_TRANSFER_ONUS_COMM," +
							"SHG_FUND_TRANSFER_OFFUS_CNT,SHG_FUND_TRANSFER_OFFUS_AMT,SHG_FUND_TRANSFER_OFFUS_COMM,AADHAR_SEEDING_CNT," +
							"AADHAR_SEEDING_AMT,AADHAR_SEEDING_COMM,RENEW_TD_AND_RD_CNT,RENEW_TD_AND_RD_AMT,RENEW_TD_AND_RD_COMM," +
							"NEFT_CNT,NEFT_AMT,NEFT_COMM,PASSBOOK_PRINTING_CNT,PASSBOOK_PRINTING_AMT,PASSBOOK_PRINTING_COMM," +
							"STOP_CHEQUE_CNT,STOP_CHEQUE_AMT,STOP_CHEQUE_COMM,SMS_ALERT_CNT,SMS_ALERT_AMT,SMS_ALERT_COMM," +
							"APPLY_NEW_DEBIT_CARD_CNT,APPLY_NEW_DEBIT_CARD_AMT,APPLY_NEW_DEBIT_CARD_COMM,BLOCK_DEBIT_CARD_CNT," +
							"BLOCK_DEBIT_CARD_AMT,BLOCK_DEBIT_CARD_COMM,NEW_CHEQUE_BOOK_REQUEST_CNT,NEW_CHEQUE_BOOK_REQUEST_AMT," +
							"NEW_CHEQUE_BOOK_REQUEST_COMM,MOBILE_SEEDING_CNT,MOBILE_SEEDING_AMT,MOBILE_SEEDING_COMM," +
							"CHEQUE_COLLECTION_CNT,CHEQUE_COLLECTION_AMT,CHEQUE_COLLECTION_COMM,ACCOPEN_AVGBAL_COMM_AMOUNT,PNB_ONE_COUNT,PNB_ONE_AMOUNT ,PNB_ONE_COMMISSION,TOTAL,CSP_SHARE,CSP_TDS,NET_PAYABLE , month,year)values"
							+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";





					/*
					 * System.out.println("DONE11");
					 */
					ps = con.prepareStatement(qry);

					ps.setString(1, NAME);
					ps.setString(2, AGENT_ID);
					ps.setString(3, CSP_LOC);
					ps.setString(4, BR_NAME);
					ps.setString(5, ACC_NO);
					ps.setString(6, PAN);
					ps.setString(7, MOBILE);
					ps.setString(8, ZONE_OFFICE_DESCRIPTION);
					ps.setString(9, CIRCLE_OFFICE);
					ps.setString(10, AGENT_TYPE);
					ps.setString(11, STATE_NAME);
					ps.setString(12, NO_OF_WORKING_DAYS);
					ps.setString(13, PMJJBY_CNT);
					ps.setString(14, PMJJBY_AMT);
					ps.setString(15, PMJJBY_COMM);
					ps.setString(16, PMSBY_CNT);
					ps.setString(17, PMSBY_AMT);
					ps.setString(18, PMSBY_COMM);
					ps.setString(19, APY_CNT);
					ps.setString(20, APY_AMT);
					ps.setString(21, APY_COMM);
					ps.setString(22, RD_CNT);
					ps.setString(23, RD_AMT);
					ps.setString(24, RD_COMM);
					ps.setString(25, FD_CNT);
					ps.setString(26, FD_AMT);
					ps.setString(27, FD_COMM);
					ps.setString(28, EKYC_ENROLLMENT_CNT);
					ps.setString(29, EKYC_ENROLLMENT_AMT);
					ps.setString(30, EKYC_ENROLLMENT_COMM);
					ps.setString(31, INDO_NEPAL_TRANSACTION_CNT);
					ps.setString(32, INDO_NEPAL_TRANSACTION_AMT);
					ps.setString(33, INDO_NEPAL_TRANSACTION);
					ps.setString(34, IMPS_TRANSACTION_CNT);
					ps.setString(35, IMPS_TRANSACTION_AMT);
					ps.setString(36, IMPS_TRANSACTION_COMM);
					ps.setString(37, AEPS_ONUS_DEPOSIT_CNT);
					ps.setString(38, AEPS_ONUS_DEPOSIT_AMT);
					ps.setString(39, AEPS_ONUS_DEPOSIT_COMM);
					ps.setString(40, AEPS_OFFUS_DEPOSIT_CNT);
					ps.setString(41, AEPS_OFFUS_DEPOSIT_AMT);
					ps.setString(42, AEPS_OFFUS_DEPOSIT_COMM);
					ps.setString(43, AEPS_ONUS_WITHDRAWAL_CNT);
					ps.setString(44, AEPS_ONUS_WITHDRAWAL_AMT);
					ps.setString(45, AEPS_ONUS_WITHDRAWAL_COMM);
					ps.setString(46, AEPS_OFFUS_WITHDRAWAL_CNT);
					ps.setString(47, AEPS_OFFUS_WITHDRAWAL_AMT);
					ps.setString(48, AEPS_OFFUS_WITHDRAWAL_COMM);
					ps.setString(49, AEPS_FUND_TRANSFER_ONUS_CNT);
					ps.setString(50, AEPS_FUND_TRANSFER_ONUS_AMT);
					ps.setString(51, AEPS_FUND_TRANSFER_ONUS_COMM);
					ps.setString(52, AEPS_FUND_TRANSFER_OFFUS_CNT);
					ps.setString(53, AEPS_FUND_TRANSFER_OFFUS_AMT);
					ps.setString(54, AEPS_FUND_TRANSFER_OFFUS_COMM);
					ps.setString(55, THIRD_PARTY_DEPOSIT_CNT);
					ps.setString(56, THIRD_PARTY_DEPOSIT_AMT);
					ps.setString(57, THIRD_PARTY_DEPOSIT_COMM);
					ps.setString(58, BBPS_CNT);
					ps.setString(59, BBPS_AMT);
					ps.setString(60, BBPS_COMM);
					ps.setString(61, RUPAY_ONUS_WITHDRWAL_CNT);
					ps.setString(62, RUPAY_ONUS_WITHDRWAL_AMT);
					ps.setString(63, RUPAY_ONUS_WITHDRWAL_COMM);
					ps.setString(64, RUPAY_OFFUS_WITHDRWAL_CNT);
					ps.setString(65, RUPAY_OFFUS_WITHDRWAL_AMT);
					ps.setString(66, RUPAY_OFFUS_WITHDRWAL_COMM);
					ps.setString(67, SHG_ONUS_WITHDRWAL_CNT);
					ps.setString(68, SHG_ONUS_WITHDRWAL_AMT);
					ps.setString(69, SHG_ONUS_WITHDRWAL_COMM);
					ps.setString(70, SHG_OFFUS_WITHDRWAL_CNT);
					ps.setString(71, SHG_OFFUS_WITHDRWAL_AMT);
					ps.setString(72, SHG_OFFUS_WITHDRWAL_COMM);
					ps.setString(73, SHG_FUND_TRANSFER_ONUS_CNT);
					ps.setString(74, SHG_FUND_TRANSFER_ONUS_AMT);
					ps.setString(75, SHG_FUND_TRANSFER_ONUS_COMM);
					ps.setString(76, SHG_FUND_TRANSFER_OFFUS_CNT);
					ps.setString(77, SHG_FUND_TRANSFER_OFFUS_AMT);
					ps.setString(78, SHG_FUND_TRANSFER_OFFUS_COMM);
					ps.setString(79, AADHAR_SEEDING_CNT);
					ps.setString(80, AADHAR_SEEDING_AMT);
					ps.setString(81, AADHAR_SEEDING_COMM);
					ps.setString(82, RENEW_TD_AND_RD_CNT);
					ps.setString(83, RENEW_TD_AND_RD_AMT);
					ps.setString(84, RENEW_TD_AND_RD_COMM);
					ps.setString(85, NEFT_CNT);
					ps.setString(86, NEFT_AMT);
					ps.setString(87, NEFT_COMM);
					ps.setString(88, PASSBOOK_PRINTING_CNT);
					ps.setString(89, PASSBOOK_PRINTING_AMT);
					ps.setString(90, PASSBOOK_PRINTING_COMM);
					ps.setString(91, STOP_CHEQUE_CNT);
					ps.setString(92, STOP_CHEQUE_AMT);
					ps.setString(93, STOP_CHEQUE_COMM);
					ps.setString(94, SMS_ALERT_CNT);
					ps.setString(95, SMS_ALERT_AMT);
					ps.setString(96, SMS_ALERT_COMM);
					ps.setString(97, APPLY_NEW_DEBIT_CARD_CNT);
					ps.setString(98, APPLY_NEW_DEBIT_CARD_AMT);
					ps.setString(99, APPLY_NEW_DEBIT_CARD_COMM);
					ps.setString(100, BLOCK_DEBIT_CARD_CNT);
					ps.setString(101, BLOCK_DEBIT_CARD_AMT);
					ps.setString(102, BLOCK_DEBIT_CARD_COMM);
					ps.setString(103, NEW_CHEQUE_BOOK_REQUEST_CNT);
					ps.setString(104, NEW_CHEQUE_BOOK_REQUEST_AMT);
					ps.setString(105, NEW_CHEQUE_BOOK_REQUEST_COMM);
					ps.setString(106, MOBILE_SEEDING_CNT);
					ps.setString(107, MOBILE_SEEDING_AMT);
					ps.setString(108, MOBILE_SEEDING_COMM);
					ps.setString(109, CHEQUE_COLLECTION_CNT);
					ps.setString(110, CHEQUE_COLLECTION_AMT);
					ps.setString(111, CHEQUE_COLLECTION_COMM);
					ps.setString(112, ACCOPEN_AVGBAL_COMM_AMOUNT);
					ps.setString(113,PNB_ONE_COUNT);
					ps.setString(114,PNB_ONE_AMOUNT);
					ps.setString(115, PNB_ONE_COMMISSION);


					ps.setString(116, TOTAL);
					ps.setString(117, CSP_SHARE);
					ps.setString(118, CSP_TDS);
					ps.setString(119, NET_PAYABLE);

					ps.setString(120, month);
					ps.setString(121, year);





					// ps.setString(40,"2021-10-10");
					// setString(41,"2021-10-10");
// 			   ps.setString(41,date);
// 			   ps.setString(40,date);

//					System.out.println(ps);
//					System.out.println(filepart);
					n = ps.executeUpdate();

				}
				if (n>0) {
					request.getSession().setAttribute("msg", "Data Uploaded Successfully");
					response.sendRedirect("uploader.jsp");
				}else {
					request.getSession().setAttribute("msg", "Data Not Uploaded-Check Data Format");
					response.sendRedirect("uploader.jsp");
				}

			} catch (Exception e) {

				message = "Error : " + e.getMessage();

				e.printStackTrace();
				out.print("Choose Excel File");
				request.getSession().setAttribute("msg", "Database Error");
				response.sendRedirect("uploader.jsp");

			} finally {
				try {
					ps.close();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				System.gc();

//				System.out.println("complete");

			}
		}

	}

	public String getValue(Cell cell1) {

		String value = "";
		if (cell1 == null) {
			return value;
		}
		/* System.out.println("cell1..." +cell1); */
		switch (cell1.getCellType()) {

		case Cell.CELL_TYPE_STRING:
			value = cell1.getRichStringCellValue().getString();
			// System.out.println("CELL_TYPE_STRING"+value);
			break;

		case Cell.CELL_TYPE_NUMERIC:
			if (DateUtil.isCellDateFormatted(cell1)) {

				value = String.valueOf(cell1.getNumericCellValue());
				// System.out.println("CELL_TYPE_NUMERIC"+value);
			} else {
				value = String.valueOf(cell1.getNumericCellValue());
				// System.out.println("CELL_TYPE_NUMERIC servvv"+value);

			}

			break;

		case Cell.CELL_TYPE_BOOLEAN:
			value = String.valueOf(cell1.getBooleanCellValue());
			// System.out.println("CELL_TYPE_BOOLEAN"+value);
			break;

		case Cell.CELL_TYPE_FORMULA:

			value = String.valueOf(cell1.getNumericCellValue());
			// System.out.println("CELL_TYPE_FORMULA"+value);
			// System.out.println("CELL_TYPE_NUMERIC servv"+cell1.getCellFormula());
			break;
		case Cell.CELL_TYPE_BLANK:

			value = "0";
			// System.out.println("CELL_TYPE_FORMULA"+value);
			// System.out.println(cell1.getCellFormula());
			break;

		case Cell.CELL_TYPE_ERROR:

			value = String.valueOf(cell1.getErrorCellValue());

		default:
			value = cell1.getRichStringCellValue().getString();
//			System.out.println("Defalut " + value);
		}
		return value;

	}

}