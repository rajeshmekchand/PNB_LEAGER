package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.conn.ConnectionController;

/**
 * Servlet implementation class login_save
 */
@WebServlet("/login_save")
public class login_save extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public login_save() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		String userid = request.getParameter("userid");
		String password = request.getParameter("password");

		String sql = "select * from user_pnb where user_id = ? and password = ?";

		Connection conn = ConnectionController.createConnection();
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, userid);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				HttpSession session = request.getSession();
				session.setAttribute("userid", userid);
				String user = rs.getString("user_id");
				String pass = rs.getString("password");
				String name = rs.getString("user_name");

				/* System.out.println("user: " + user + " pass: " + pass + " name: " + name); */
				session.setAttribute("name", name);

				if(rs.getString("role").equalsIgnoreCase("admin")){
				 session.setAttribute("role","admin");
				response.sendRedirect("uploader.jsp");
				 }else if(rs.getString("role").equalsIgnoreCase("user")) {
				 session.setAttribute("role","user");
				 response.sendRedirect("client.jsp");
				 request.getSession().removeAttribute("ms1");
					}else {
						request.getSession().setAttribute("ms1", "Invalid Userid & Password");
						response.sendRedirect("index.jsp");
					}

					} else {
						request.getSession().setAttribute("ms1", "Invalid Userid & Password");
						response.sendRedirect("index.jsp");
					}
					rs.close();


				} catch (SQLException e) {
					e.printStackTrace();
					request.getSession().setAttribute("ms1", "Invalid Userid & Password");
					response.sendRedirect("index.jsp");
				} finally {
					try {
						ps.close();
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}

			}
		}
