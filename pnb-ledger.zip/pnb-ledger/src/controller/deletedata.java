package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.conn.ConnectionController;

/**
 * Servlet implementation class deletedata
 */
@WebServlet("/deletedata")
public class deletedata extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public deletedata() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String month=request.getParameter("month");
		String year=request.getParameter("year");
		/* System.out.println("month- "+month+ " year- "+year); */
		String message=null;
		Connection con = ConnectionController.createConnection();
		PreparedStatement ps = null;
		String sql="DELETE  FROM sgb_pnb WHERE month=? and year=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, month);
			ps.setString(2, year);
			int i=ps.executeUpdate();
			if (i>0) {
			request.getSession().setAttribute("msg1", "Data Deleted Successfully");
			response.sendRedirect("csp_report.jsp");
			}else {
				request.getSession().setAttribute("msg1", "Cant Deleted");
				response.sendRedirect("csp_report.jsp");
			}
		}catch (Exception e) {

			message = "Error : " + e.getMessage();

			e.printStackTrace();

			request.getSession().setAttribute("msg1", "Error Database");
			response.sendRedirect("csp_report.jsp");

		} finally {
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			System.gc();

//			System.out.println("complete");

		}
	}

}
