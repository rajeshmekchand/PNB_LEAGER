package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.conn.ConnectionController;

/**
 * Servlet implementation class pwd_change
 */
@WebServlet("/pwd_change")
public class pwd_change extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public pwd_change() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String r_userid=request.getParameter("userid");
		String n_pass=request.getParameter("pass");
		Connection con = ConnectionController.createConnection();
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		String sql="update user_pnb set password=? where user_id=?";
		String sql1="select * from user_pnb where user_id=? ";
		/* System.out.println(sql1); */
		try {
			ps1=con.prepareStatement(sql1);
			ps1.setString(1, r_userid);
			ResultSet rs = ps1.executeQuery();
			/* System.out.println(rs); */
			if (rs.next()) {
				/* System.out.println("done"); */
				if(rs.getString("role").equalsIgnoreCase("admin")){
					/* System.out.println("admin"); */
					request.getSession().setAttribute("msg2", "Not Authorize to Change Admin");
					response.sendRedirect("csp_report.jsp");
				}else if(rs.getString("role").equalsIgnoreCase("user")) {
					/* System.out.println("user"); */
					ps=con.prepareStatement(sql);
					ps.setString(1, n_pass);
					ps.setString(2, r_userid);
					int i=ps.executeUpdate();
					if (i>0) {
						request.getSession().setAttribute("msg2", "Password Updated");
						response.sendRedirect("csp_report.jsp");

						}else {
							request.getSession().setAttribute("msg2", "Agent Id Not Found");
							response.sendRedirect("csp_report.jsp");
						}
					ps.close();
				}
			}




		}catch (Exception e) {

			e.printStackTrace();

			request.getSession().setAttribute("msg2", " Error 404");
			response.sendRedirect("csp_report.jsp");

		} finally {
			try {
				ps1.close();

				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			System.gc();

//			System.out.println("complete");

		}
	}

}